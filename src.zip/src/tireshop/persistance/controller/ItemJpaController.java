/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tireshop.persistance.controller;

import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;
import java.io.Serializable;
import java.sql.SQLException;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import tireshop.persistance.entity.Manufacturer;
import tireshop.persistance.entity.VehicleType;
import tireshop.persistance.entity.SupplyOrderDetail;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import tireshop.persistance.controller.exceptions.MyRemoteEx;
import tireshop.persistance.controller.exceptions.NonexistentEntityException;
import tireshop.persistance.entity.Item;
import tireshop.remote.RemoteDBHandler;

/**
 *
 * @author Thilina
 */
public class ItemJpaController extends Observable implements Serializable {

    public ItemJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Item item) {
        if (item.getSupplyOrderDetails() == null) {
            item.setSupplyOrderDetails(new ArrayList<SupplyOrderDetail>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Manufacturer manufacturer = item.getManufacturer();
            if (manufacturer != null) {
                manufacturer = em.getReference(manufacturer.getClass(), manufacturer.getManuid());
                item.setManufacturer(manufacturer);
            }
            VehicleType vehicleType = item.getVehicleType();
            if (vehicleType != null) {
                vehicleType = em.getReference(vehicleType.getClass(), vehicleType.getVid());
                item.setVehicleType(vehicleType);
            }
            List<SupplyOrderDetail> attachedSupplyOrderDetails = new ArrayList<SupplyOrderDetail>();
            for (SupplyOrderDetail supplyOrderDetailsSupplyOrderDetailToAttach : item.getSupplyOrderDetails()) {
                supplyOrderDetailsSupplyOrderDetailToAttach = em.getReference(supplyOrderDetailsSupplyOrderDetailToAttach.getClass(), supplyOrderDetailsSupplyOrderDetailToAttach.getSodid());
                attachedSupplyOrderDetails.add(supplyOrderDetailsSupplyOrderDetailToAttach);
            }
            item.setSupplyOrderDetails(attachedSupplyOrderDetails);
            em.persist(item);
            if (manufacturer != null) {
                manufacturer.getItems().add(item);
                manufacturer = em.merge(manufacturer);
            }
            if (vehicleType != null) {
                vehicleType.getItems().add(item);
                vehicleType = em.merge(vehicleType);
            }
            for (SupplyOrderDetail supplyOrderDetailsSupplyOrderDetail : item.getSupplyOrderDetails()) {
                Item oldItemOfSupplyOrderDetailsSupplyOrderDetail = supplyOrderDetailsSupplyOrderDetail.getItem();
                supplyOrderDetailsSupplyOrderDetail.setItem(item);
                supplyOrderDetailsSupplyOrderDetail = em.merge(supplyOrderDetailsSupplyOrderDetail);
                if (oldItemOfSupplyOrderDetailsSupplyOrderDetail != null) {
                    oldItemOfSupplyOrderDetailsSupplyOrderDetail.getSupplyOrderDetails().remove(supplyOrderDetailsSupplyOrderDetail);
                    oldItemOfSupplyOrderDetailsSupplyOrderDetail = em.merge(oldItemOfSupplyOrderDetailsSupplyOrderDetail);
                }
            }
            em.getTransaction().commit();

//            System.out.println("sd "+item.getIid()+",'"+item.getCategory().toString()+"','"+item.getName()+"','"+item.getTubeType().toString()+"','"
//            +item.getConstruction().getCid()+"','"+item.getManufacturer().getManuid()+"','"+item.getVehicleType().getVid());
            try {
                RemoteDBHandler.setData("INSERT INTO item (IID, CATEGORY, NAME, TUBETYPE, CONSTRUCTION_CID, MANUFACTURER_MANUID,"
                        + "VEHICLETYPE_VID) VALUES(" + item.getIid() + ",'" + item.getCategory().toString() + "','" + item.getName() + "','" + item.getTubeType().toString() + "','"
                        + item.getConstruction().getCid() + "','" + item.getManufacturer().getManuid() + "','" + item.getVehicleType().getVid() + "')");
            } catch (Exception e) {
            }

            // Logger.getLogger(ItemJpaController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Item item) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Item persistentItem = em.find(Item.class, item.getIid());
            Manufacturer manufacturerOld = persistentItem.getManufacturer();
            Manufacturer manufacturerNew = item.getManufacturer();
            VehicleType vehicleTypeOld = persistentItem.getVehicleType();
            VehicleType vehicleTypeNew = item.getVehicleType();
            List<SupplyOrderDetail> supplyOrderDetailsOld = persistentItem.getSupplyOrderDetails();
            List<SupplyOrderDetail> supplyOrderDetailsNew = item.getSupplyOrderDetails();
            if (manufacturerNew != null) {
                manufacturerNew = em.getReference(manufacturerNew.getClass(), manufacturerNew.getManuid());
                item.setManufacturer(manufacturerNew);
            }
            if (vehicleTypeNew != null) {
                vehicleTypeNew = em.getReference(vehicleTypeNew.getClass(), vehicleTypeNew.getVid());
                item.setVehicleType(vehicleTypeNew);
            }
            List<SupplyOrderDetail> attachedSupplyOrderDetailsNew = new ArrayList<>();
            for (SupplyOrderDetail supplyOrderDetailsNewSupplyOrderDetailToAttach : supplyOrderDetailsNew) {
                supplyOrderDetailsNewSupplyOrderDetailToAttach = em.getReference(supplyOrderDetailsNewSupplyOrderDetailToAttach.getClass(), supplyOrderDetailsNewSupplyOrderDetailToAttach.getSodid());
                attachedSupplyOrderDetailsNew.add(supplyOrderDetailsNewSupplyOrderDetailToAttach);
            }
            supplyOrderDetailsNew = attachedSupplyOrderDetailsNew;
            item.setSupplyOrderDetails(supplyOrderDetailsNew);
            item = em.merge(item);
            if (manufacturerOld != null && !manufacturerOld.equals(manufacturerNew)) {
                manufacturerOld.getItems().remove(item);
                manufacturerOld = em.merge(manufacturerOld);
            }
            if (manufacturerNew != null && !manufacturerNew.equals(manufacturerOld)) {
                manufacturerNew.getItems().add(item);
                manufacturerNew = em.merge(manufacturerNew);
            }
            if (vehicleTypeOld != null && !vehicleTypeOld.equals(vehicleTypeNew)) {
                vehicleTypeOld.getItems().remove(item);
                vehicleTypeOld = em.merge(vehicleTypeOld);
            }
            if (vehicleTypeNew != null && !vehicleTypeNew.equals(vehicleTypeOld)) {
                vehicleTypeNew.getItems().add(item);
                vehicleTypeNew = em.merge(vehicleTypeNew);
            }
            for (SupplyOrderDetail supplyOrderDetailsOldSupplyOrderDetail : supplyOrderDetailsOld) {
                if (!supplyOrderDetailsNew.contains(supplyOrderDetailsOldSupplyOrderDetail)) {
                    supplyOrderDetailsOldSupplyOrderDetail.setItem(null);
                    supplyOrderDetailsOldSupplyOrderDetail = em.merge(supplyOrderDetailsOldSupplyOrderDetail);
                }
            }
            for (SupplyOrderDetail supplyOrderDetailsNewSupplyOrderDetail : supplyOrderDetailsNew) {
                if (!supplyOrderDetailsOld.contains(supplyOrderDetailsNewSupplyOrderDetail)) {
                    Item oldItemOfSupplyOrderDetailsNewSupplyOrderDetail = supplyOrderDetailsNewSupplyOrderDetail.getItem();
                    supplyOrderDetailsNewSupplyOrderDetail.setItem(item);
                    supplyOrderDetailsNewSupplyOrderDetail = em.merge(supplyOrderDetailsNewSupplyOrderDetail);
                    if (oldItemOfSupplyOrderDetailsNewSupplyOrderDetail != null && !oldItemOfSupplyOrderDetailsNewSupplyOrderDetail.equals(item)) {
                        oldItemOfSupplyOrderDetailsNewSupplyOrderDetail.getSupplyOrderDetails().remove(supplyOrderDetailsNewSupplyOrderDetail);
                        oldItemOfSupplyOrderDetailsNewSupplyOrderDetail = em.merge(oldItemOfSupplyOrderDetailsNewSupplyOrderDetail);
                    }
                }
            }
            em.getTransaction().commit();
            try {
                RemoteDBHandler.setData("UPDATE item SET NAME='" + item.getName() + "', "
                        + "CATEGORY='" + item.getCategory().toString() + "', "
                        + "TUBETYPE='" + item.getTubeType().toString() + "', "
                        + "CONSTRUCTION_CID='" + item.getConstruction().getCid() + "', "
                        + "MANUFACTURER_MANUID='" + item.getManufacturer().getManuid() + "', "
                        + "VEHICLETYPE_VID='" + item.getVehicleType().getVid() + "'"
                        + " WHERE IID='" + item.getIid() + "'");
            } catch (Exception e) {
            }
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = item.getIid();
                if (findItem(id) == null) {
                    throw new NonexistentEntityException("The item with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Item item;
            try {
                item = em.getReference(Item.class, id);
                item.getIid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The item with id " + id + " no longer exists.", enfe);
            }
            Manufacturer manufacturer = item.getManufacturer();
            if (manufacturer != null) {
                manufacturer.getItems().remove(item);
                manufacturer = em.merge(manufacturer);
            }
            VehicleType vehicleType = item.getVehicleType();
            if (vehicleType != null) {
                vehicleType.getItems().remove(item);
                vehicleType = em.merge(vehicleType);
            }
            List<SupplyOrderDetail> supplyOrderDetails = item.getSupplyOrderDetails();
            for (SupplyOrderDetail supplyOrderDetailsSupplyOrderDetail : supplyOrderDetails) {
                supplyOrderDetailsSupplyOrderDetail.setItem(null);
                supplyOrderDetailsSupplyOrderDetail = em.merge(supplyOrderDetailsSupplyOrderDetail);
            }
            em.remove(item);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Item> findItemEntities() {
        return findItemEntities(true, -1, -1);
    }

    public List<Item> findItemEntities(int maxResults, int firstResult) {
        return findItemEntities(false, maxResults, firstResult);
    }

    private List<Item> findItemEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Item.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Item findItem(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Item.class, id);
        } finally {
            em.close();
        }
    }

    public int getItemCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Item> rt = cq.from(Item.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    @Override
    public void setChanged() {
        super.setChanged();
    }

    public Item findItemForNameAndManu(String itemName, String manufacturer) {
        String ejbql = "SELECT i from Item i WHERE i.name = :pattern AND i.manufacturer.name=:manu";
        Query query = getEntityManager().createQuery(ejbql);
        StringBuilder sb = new StringBuilder();
        //sb.append("%");
        sb.append(itemName);
//        sb.append("%");
        query.setParameter("pattern", sb.toString());
        sb = new StringBuilder();
        sb.append(manufacturer);
        query.setParameter("manu", sb.toString());
        List<Item> resultList = query.getResultList();
        if (resultList != null && resultList.size() > 0) {
            return resultList.get(0);
        } else {
            return null;
        }
    }
}
