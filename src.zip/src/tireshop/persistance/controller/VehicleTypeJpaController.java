/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tireshop.persistance.controller;

import com.mysql.jdbc.exceptions.jdbc4.CommunicationsException;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import tireshop.persistance.controller.exceptions.NonexistentEntityException;
import tireshop.persistance.entity.Manufacturer;
import tireshop.persistance.entity.VehicleType;
import tireshop.remote.RemoteDBHandler;

/**
 *
 * @author Sandaruwan
 */
public class VehicleTypeJpaController implements Serializable {

    public VehicleTypeJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(VehicleType vehicleType) throws ClassNotFoundException, SQLException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(vehicleType);
            em.getTransaction().commit();
            try {
                RemoteDBHandler.setData("INSERT INTO vehicletype (VID, NAME) "
                        + "VALUES('" + vehicleType.getVid() + "','" + vehicleType.getName() + "')");
            } catch (Exception ce) {
            }
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(VehicleType vehicleType) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            vehicleType = em.merge(vehicleType);
            em.getTransaction().commit();
            try {
                RemoteDBHandler.setData("UPDATE SET NAME='" + vehicleType.getName() + "' WHERE VID='" + vehicleType.getVid() + "'");
            } catch (Exception ce) {
            }
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Long id = vehicleType.getVid();
                if (findVehicleType(id) == null) {
                    throw new NonexistentEntityException("The vehicleType with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Long id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            VehicleType vehicleType;
            try {
                vehicleType = em.getReference(VehicleType.class, id);
                vehicleType.getVid();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The vehicleType with id " + id + " no longer exists.", enfe);
            }
            em.remove(vehicleType);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<VehicleType> findVehicleTypeEntities() {
        return findVehicleTypeEntities(true, -1, -1);
    }

    public List<VehicleType> findVehicleTypeEntities(int maxResults, int firstResult) {
        return findVehicleTypeEntities(false, maxResults, firstResult);
    }

    private List<VehicleType> findVehicleTypeEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(VehicleType.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public VehicleType findVehicleType(Long id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(VehicleType.class, id);
        } finally {
            em.close();
        }
    }

    public int getVehicleTypeCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<VehicleType> rt = cq.from(VehicleType.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }

    public VehicleType getVehicleTypeForName(String name) {
        String ejbql = "SELECT vt from VehicleType vt WHERE vt.name LIKE :pattern";
        Query query = getEntityManager().createQuery(ejbql);
        StringBuilder sb = new StringBuilder();
        sb.append("%");
        sb.append(name);
        sb.append("%");
        query.setParameter("pattern", sb.toString());
        List<VehicleType> resultList = query.getResultList();
        if (resultList != null && resultList.size() > 0) {
            return resultList.get(0);
        } else {
            return null;
        }
    }
}
