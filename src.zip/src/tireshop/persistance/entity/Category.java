/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tireshop.persistance.entity;

/**
 *
 * @author Thilina
 */
public enum Category {

    /**
     *
     */
    Tire,
    /**
     *
     */
    Tube,
    /**
     *
     */
    Alloy_Wheel,
    /**
     *
     */
    Other_Retail,
    Undifined;
}
