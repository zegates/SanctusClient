/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tireshop.persistance.factory;

import tireshop.persistance.controller.ConstructionJpaController;
import tireshop.persistance.controller.ItemJpaController;
import tireshop.persistance.controller.LogSessionJpaController;
import tireshop.persistance.controller.LogUserJpaController;
import tireshop.persistance.controller.ManufacturerJpaController;
import tireshop.persistance.controller.OrdersJpaController;
import tireshop.persistance.controller.SupplierJpaController;
import tireshop.persistance.controller.SupplyOrderDetailJpaController;
import tireshop.persistance.controller.SupplyOrderJpaController;
import tireshop.persistance.controller.VehicleTypeJpaController;

/**
 *
 * @author Sandaruwan
 */
public class ControllerFactory {

    private static OrdersJpaController ojc;
    private static ItemJpaController ijc;
    private static SupplierJpaController sjc;

    static {
        ojc = new OrdersJpaController(EMFHandler.getEmf());
        ijc = new ItemJpaController(EMFHandler.getEmf());
        sjc=new SupplierJpaController(EMFHandler.getEmf());
    }

    public static ItemJpaController getItemJpaController() {
        return ijc;
    }

    public static ManufacturerJpaController getManufacturerJpaController() {
        return new ManufacturerJpaController(EMFHandler.getEmf());
    }

    public static ConstructionJpaController getConstructionJpaController() {
        return new ConstructionJpaController(EMFHandler.getEmf());
    }

    public static VehicleTypeJpaController getVehicleTypeJpaController() {
        return new VehicleTypeJpaController(EMFHandler.getEmf());
    }

    public static SupplyOrderDetailJpaController getSupplyOrderDetailJpaController() {
        return new SupplyOrderDetailJpaController(EMFHandler.getEmf());
    }

    public static SupplierJpaController getSupplierJpaController() {
        return sjc;
    }

    public static SupplyOrderJpaController getSupplyOrderJpaController() {
        return new SupplyOrderJpaController(EMFHandler.getEmf());
    }

    public static OrdersJpaController getOrdersJpaController() {
        return ojc;
    }

    public static LogSessionJpaController getSessionJpaController() {
        return new LogSessionJpaController(EMFHandler.getEmf());
    }

    public static LogUserJpaController getLogUserJpaController() {
        return new LogUserJpaController(EMFHandler.getEmf());
    }
}
